<?php

namespace lanterna\faliky;

use pocketmine\plugin\PluginBase as P;
use pocketmine\event\Listener as L;

use pocketmine\player\Player;
use pocketmine\utils\Config;

use pocketmine\Server;

use pocketmine\command\{Command, CommandSender};

use pocketmine\world\sound\Sound;
use pocketmine\world\sound\{AnvilUseSound, XpCollectSound};

use pocketmine\world\World;
use pocketmine\world\Position;

use pocketmine\entity\effect\EffectManager;
use pocketmine\entity\effect\EffectInstance;
use pocketmine\entity\effect\Effect;
use pocketmine\entity\effect\VanillaEffects;

class Loader extends P implements L {
    
    public function onLoad(): void {
        
        //null
        
    }
    
    public function onEnable(): void {
        
        @mkdir($this->getDataFolder());
        $this->msg = new Config($this->getDataFolder()."messages.yml", Config::YAML, [
            
            "message-on" => "§r§aLuz ativada com sucesso!",
            "message-off" => "§r§cLuz desativada com sucesso!",
            "title-on" => "§l§eLANTERNA\n\n§r§fModo: §aAtivado!",
            "title-off" => "§l§eLANTERNA\n\n§r§fModo: §cDesativado!",
            //
            "message-usage" => "§r§eUtilize §f/luz [ on | off ]"
            
        ]);
        
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
        
    }
    
    public function onDisable(): void {
        
        //null
        
    }
    
    /** @var add Luz Player */
    public function addLuz(Player $player) {
        
        $player->getEffects()->remove(VanillaEffects::NIGHT_VISION());
        
        $effectManager = $player->getEffects();
        
        $sNightVision = new EffectInstance(VanillaEffects::NIGHT_VISION(), 999999*20, 0);
        
        $effectManager->add($sNightVision);
        
    }
    
    /** @var remove Luz Player */
    public function rmLuz(Player $player){
        
        $player->getEffects()->remove(VanillaEffects::NIGHT_VISION());
        
    }
    
    public function onCommand(CommandSender $player, Command $cmd, string $l, array $args): bool {
        
        if(strtolower($cmd->getName()) == "lanterna"){
            
            if(!isset($args[0])){
                
                $player->sendMessage($this->msg->get("message-usage"));
                $player->getWorld()->addSound($player->getPosition()->asVector3(), new AnvilUseSound(100));
                return false;
                
            }
            
            if(strtolower($args[0]) == "on"){
                
                $this->addLuz($player);
                $player->sendMessage($this->msg->get("message-on"));
                $player->sendTitle($this->msg->get("title-on"));
                
                $player->getWorld()->addSound($player->getPosition()->asVector3(), new XpCollectSound(100));
                
            }
            
            if(strtolower($args[0]) == "off"){
                
                $this->rmLuz($player);
                $player->sendMessage($this->msg->get("message-off"));
                $player->sendTitle($this->msg->get("title-off"));
                
                $player->getWorld()->addSound($player->getPosition()->asVector3(), new XpCollectSound(100));
                
            }
            
        }
        
        return true;
    
    }
}